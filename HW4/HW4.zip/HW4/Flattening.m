function [y] = Flattening(x)
    y=x(:);
end