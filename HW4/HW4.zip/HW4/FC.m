function y = FC(x, w, b)
    y = w*x + b;
end