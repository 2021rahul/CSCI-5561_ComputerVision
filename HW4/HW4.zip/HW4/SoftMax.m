function y = SoftMax(x)
    y = exp(x)/sum(exp(x));
end